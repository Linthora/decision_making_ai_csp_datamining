/**
 * A package containing various utility components for our project.
 */
package utility;