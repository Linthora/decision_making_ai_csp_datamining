/**
 * Package containing planning tools we could use to solve (if possible) problems that can be represented like graphs with action to move from one state to another.
 */
package planning;