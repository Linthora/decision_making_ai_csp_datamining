/**
 * Package containing all the components to represent and manipulate a block world.
 * And also serveral demonstration of what can be done with the other packages of the project.
 */
package blockworld;