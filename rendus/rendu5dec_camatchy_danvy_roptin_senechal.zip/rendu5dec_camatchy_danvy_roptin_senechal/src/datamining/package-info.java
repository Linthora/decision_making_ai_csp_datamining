/**
 * Package containing data mining tools we could use to mine frequent itemsets from a database and look for association rules.
 */
package datamining;