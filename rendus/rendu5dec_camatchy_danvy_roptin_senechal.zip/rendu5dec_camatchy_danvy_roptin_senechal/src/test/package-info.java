/**
 * A package containing the tests for our project and exectutabables to run them.
 */
package test;
