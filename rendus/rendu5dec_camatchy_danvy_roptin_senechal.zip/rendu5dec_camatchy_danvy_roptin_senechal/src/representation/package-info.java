/**
 * Package containing all the components to represent a problem 
 * with variables and constraints.
 */
package representation;