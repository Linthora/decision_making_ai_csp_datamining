/**
 * Package containing CSP tools we could use to solve (if possible) CSP porblems.
 */
package csp;